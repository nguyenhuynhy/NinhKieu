var childLeft = 0
var childTop = 0

function openWindow(url) {
  childLeft += 20;
  childTop += 20;
  window.open(url, "_blank", "width=640 height=480 left="+childLeft+" top="+childTop+" location=1 toolbar=0 statusbar=0 scrollbars=1 resizable=1")
}

function UpdateViewsourceLinks() {
  var colA = document.all.tags("A");
  for ( i = 0; i < colA.length; i++ ) {
    var A = colA(i);
    if ( A.className == "viewsource" ) {
      A.href = "view-source:"+A.href;
      A.style.visibility = "visible";
    }
  }
}
