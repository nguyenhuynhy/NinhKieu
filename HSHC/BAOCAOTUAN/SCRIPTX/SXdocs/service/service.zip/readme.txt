ScriptX Printing - Server Side Deployment Service Helper
--------------------------------------------------------


This is per the sample referenced at http://support.microsoft.com/default.aspx?scid=kb;EN-US;q288367 with irrelevant stuff like incrementing the demo counter removed. The service literally does nothing other than sleep, wake up and go straight back to sleep again. 

To ensure the registry load occurs for and is used by the ScriptX Printing component reboot the machine before installing the service if the Printing components have been used - at the least a full reboot of IIS (iisadmin).

From a command prompt:

>service -v

This will list the version info and should say the service is not installed.

>service -i

Will install the service. You then need to use the Service Control Manager (The service is called MeadCo PrintX Service) and setup as per-usual with an identity (one might also make the service auto-start rather than manual). Event viewer will list various application events for the service: Install, Start, Stop and Uninstall.

>service -u 

Will uninstall the service.


MeadCo Zeepe Toolkit Development Team.
1-May-2002